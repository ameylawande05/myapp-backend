// src/routes/auth.js
const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const { query }     = require('../utils/db');
const { signToken, verifyToken } = require('../middleware/auth');
const { shopPhotoUpload, getFileUrl } = require('../middleware/upload');

const COUNTRY_PREFIXES = {
  'Afghanistan':'AFG','Albania':'ALB','Algeria':'DZA','Argentina':'ARG','Australia':'AUS',
  'Austria':'AUT','Bangladesh':'BGD','Belgium':'BEL','Brazil':'BRA','Cambodia':'KHM',
  'Canada':'CAN','Chile':'CHL','China':'CHN','Colombia':'COL','Denmark':'DNK',
  'Egypt':'EGY','Ethiopia':'ETH','Finland':'FIN','France':'FRA','Germany':'DEU',
  'Ghana':'GHA','Greece':'GRC','Hong Kong':'HKG','Hungary':'HUN','India':'IND',
  'Indonesia':'IDN','Iran':'IRN','Iraq':'IRQ','Ireland':'IRL','Israel':'ISR',
  'Italy':'ITA','Japan':'JPN','Jordan':'JOR','Kenya':'KEN','Kuwait':'KWT',
  'Laos':'LAO','Lebanon':'LBN','Malaysia':'MYS','Mexico':'MEX','Morocco':'MAR',
  'Myanmar':'MMR','Nepal':'NPL','Netherlands':'NLD','New Zealand':'NZL','Nigeria':'NGA',
  'Norway':'NOR','Pakistan':'PAK','Philippines':'PHL','Poland':'POL','Portugal':'PRT',
  'Qatar':'QAT','Romania':'ROU','Russia':'RUS','Saudi Arabia':'SAU','Singapore':'SGP',
  'South Africa':'ZAF','South Korea':'KOR','Spain':'ESP','Sri Lanka':'LKA','Sweden':'SWE',
  'Switzerland':'CHE','Taiwan':'TWN','Thailand':'THA','Turkey':'TUR','Ukraine':'UKR',
  'United Arab Emirates':'ARE','United Kingdom':'GBR','United States':'USA',
  'Vietnam':'VNM','Zimbabwe':'ZWE'
};

function generateCustomerId(country) {
  const pfx = COUNTRY_PREFIXES[country] || country.slice(0, 3).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `${pfx}-${rand}`;
}

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const { rows } = await query('SELECT * FROM users WHERE email = $1', [email.toLowerCase().trim()]);
    const user = rows[0];

    if (!user) return res.status(401).json({ error: 'Invalid email or password' });

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid email or password' });

    if (!user.approved && user.role !== 'admin') {
      return res.status(403).json({ error: 'Account pending admin approval. You will be notified by email once approved.' });
    }

    const token = signToken({ id: user.id, role: user.role, email: user.email });
    const { password_hash, ...safe } = user;

    await query('INSERT INTO audit_log (action, actor, target, detail) VALUES ($1,$2,$3,$4)',
      ['User Login', user.email, user.id, 'Successful login']);

    res.json({ token, user: safe });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/auth/register
router.post('/register', (req, res, next) => {
  shopPhotoUpload(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    next();
  });
}, async (req, res) => {
  try {
    const { name, business, email, password, country, pincode, address, mobile } = req.body;

    if (!name || !business || !email || !password || !country) {
      return res.status(400).json({ error: 'Name, business, email, password, and country are required' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const exists = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase().trim()]);
    if (exists.rows.length) return res.status(409).json({ error: 'Email already registered' });

    const hash     = await bcrypt.hash(password, 12);
    const id       = generateCustomerId(country);
    const photoUrl = req.file ? getFileUrl(req, req.file) : null;

    await query(`
      INSERT INTO users (id, role, name, business, email, password_hash, approved, country, pincode, address, mobile, shop_photo_url)
      VALUES ($1, 'channel', $2, $3, $4, $5, FALSE, $6, $7, $8, $9, $10)
    `, [id, name, business, email.toLowerCase().trim(), hash, country, pincode || '', address || '', mobile || '', photoUrl]);

    await query('INSERT INTO audit_log (action, actor, target, detail) VALUES ($1,$2,$3,$4)',
      ['User Registered', email, id, `${business} registered from ${country} — pending approval`]);

    res.status(201).json({
      message: 'Registration submitted successfully! You will receive an email once approved.',
      customerId: id,
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/auth/me
router.get('/me', verifyToken, async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT id,role,name,business,email,approved,country,pincode,address,mobile,shop_photo_url,created_at FROM users WHERE id = $1',
      [req.user.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'User not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
