// src/routes/submissions.js
const router = require('express').Router();
const { query }  = require('../utils/db');
const { verifyToken, requireAdmin } = require('../middleware/auth');
const { submissionUpload, getFileUrl } = require('../middleware/upload');
const { notifyNewSubmission, notifyApproved, notifyRejected } = require('../utils/email');

function uid() { return Math.random().toString(36).slice(2, 9).toUpperCase(); }

// GET /api/submissions
router.get('/', verifyToken, async (req, res) => {
  try {
    let sql = `
      SELECT s.*, u.email AS customer_email
      FROM submissions s
      LEFT JOIN users u ON s.customer_id = u.id
    `;
    const params = [];

    if (req.user.role !== 'admin') {
      sql += ' WHERE s.customer_id = $1';
      params.push(req.user.id);
    }

    sql += ' ORDER BY s.submitted_at DESC';
    const { rows } = await query(sql, params);

    // Attach invoices
    for (const sub of rows) {
      const inv = await query('SELECT * FROM submission_invoices WHERE submission_id = $1 ORDER BY uploaded_at', [sub.id]);
      sub.invoices = inv.rows;
    }

    res.json(rows);
  } catch (err) {
    console.error('GET /submissions:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/submissions/:id
router.get('/:id', verifyToken, async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT s.*, u.email AS customer_email
      FROM submissions s LEFT JOIN users u ON s.customer_id = u.id
      WHERE s.id = $1
    `, [req.params.id]);

    if (!rows[0]) return res.status(404).json({ error: 'Submission not found' });
    if (req.user.role !== 'admin' && rows[0].customer_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const inv = await query('SELECT * FROM submission_invoices WHERE submission_id = $1', [req.params.id]);
    rows[0].invoices = inv.rows;
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/submissions — create new claim
router.post('/', verifyToken, (req, res, next) => {
  submissionUpload(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    next();
  });
}, async (req, res) => {
  try {
    const { month, distributorId, distributorHelped } = req.body;
    if (!month || !distributorId) return res.status(400).json({ error: 'Month and distributor are required' });

    const custQ = await query('SELECT name, business, country FROM users WHERE id = $1', [req.user.id]);
    const cust  = custQ.rows[0];
    if (!cust) return res.status(404).json({ error: 'Customer not found' });

    const distQ = await query('SELECT name FROM distributors WHERE id = $1', [distributorId]);
    const dist  = distQ.rows[0];

    const files = req.files || {};
    const id    = 'SUB-' + uid();

    const displayVideo    = files.displayVideo?.[0];
    const photo1          = files.photo1?.[0];
    const businessCard    = files.businessCard?.[0];

    await query(`
      INSERT INTO submissions (
        id, customer_id, customer_name, country, month,
        distributor_id, distributor_name,
        display_video_url, display_video_name,
        photo1_url, photo1_name,
        business_card_url, business_card_name,
        distributor_helped, status
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,'Pending Review')
    `, [
      id, req.user.id, cust.business || cust.name, cust.country, month,
      distributorId, dist?.name || '',
      displayVideo ? getFileUrl(req, displayVideo) : null, displayVideo?.originalname || null,
      photo1       ? getFileUrl(req, photo1)       : null, photo1?.originalname       || null,
      businessCard ? getFileUrl(req, businessCard) : null, businessCard?.originalname || null,
      distributorHelped || 'Yes',
    ]);

    // Save invoices
    if (files.invoices && files.invoices.length > 0) {
      for (const inv of files.invoices) {
        await query(
          'INSERT INTO submission_invoices (submission_id, file_url, file_name, file_size) VALUES ($1,$2,$3,$4)',
          [id, getFileUrl(req, inv), inv.originalname, inv.size]
        );
      }
    }

    await query('INSERT INTO audit_log (action, actor, target, detail) VALUES ($1,$2,$3,$4)',
      ['Submission Created', req.user.email, id, `${month} claim submitted`]);

    // Email head office
    const sub = (await query('SELECT * FROM submissions WHERE id = $1', [id])).rows[0];
    await notifyNewSubmission(sub);

    res.status(201).json({ id, message: 'Claim submitted successfully! Head office has been notified.' });
  } catch (err) {
    console.error('POST /submissions:', err);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
});

// PATCH /api/submissions/:id/verify — save admin verification fields
router.patch('/:id/verify', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { boxes_displayed, reams_purchased, posm_displayed, eligible_incentive, incentive_amount, currency } = req.body;
    await query(`
      UPDATE submissions SET
        boxes_displayed   = $1,
        reams_purchased   = $2,
        posm_displayed    = $3,
        eligible_incentive= $4,
        incentive_amount  = $5,
        currency          = $6,
        updated_at        = NOW()
      WHERE id = $7
    `, [boxes_displayed, reams_purchased, posm_displayed, eligible_incentive, incentive_amount, currency, req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PATCH /api/submissions/:id/approve
router.patch('/:id/approve', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { rows } = await query('SELECT * FROM submissions WHERE id = $1', [req.params.id]);
    const sub = rows[0];
    if (!sub) return res.status(404).json({ error: 'Submission not found' });

    // Validate all 6 verification fields are filled
    if (!sub.boxes_displayed || !sub.reams_purchased || !sub.posm_displayed ||
        !sub.eligible_incentive || !sub.incentive_amount || !sub.currency) {
      return res.status(400).json({
        error: 'Please fill all 6 verification fields (Boxes, Reams, POSM, Eligible, Amount, Currency) before approving.'
      });
    }

    await query(`
      UPDATE submissions SET status = 'Approved', reviewed_by = $1, reviewed_at = NOW(), updated_at = NOW()
      WHERE id = $2
    `, [req.user.id, req.params.id]);

    await query('INSERT INTO audit_log (action, actor, target, detail) VALUES ($1,$2,$3,$4)',
      ['Submission Approved', req.user.email, req.params.id, 'Approved with full verification data']);

    const custQ = await query('SELECT * FROM users WHERE id = $1', [sub.customer_id]);
    const updatedSub = (await query('SELECT * FROM submissions WHERE id = $1', [req.params.id])).rows[0];
    await notifyApproved(updatedSub, custQ.rows[0]);

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PATCH /api/submissions/:id/reject
router.patch('/:id/reject', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { reason } = req.body;
    if (!reason || !reason.trim()) return res.status(400).json({ error: 'Rejection reason is required' });

    const { rows } = await query('SELECT * FROM submissions WHERE id = $1', [req.params.id]);
    const sub = rows[0];
    if (!sub) return res.status(404).json({ error: 'Submission not found' });

    await query(`
      UPDATE submissions SET status = 'Rejected', reviewer_note = $1, reviewed_by = $2, reviewed_at = NOW(), updated_at = NOW()
      WHERE id = $3
    `, [reason, req.user.id, req.params.id]);

    await query('INSERT INTO audit_log (action, actor, target, detail) VALUES ($1,$2,$3,$4)',
      ['Submission Rejected', req.user.email, req.params.id, 'Rejected: ' + reason]);

    const custQ = await query('SELECT * FROM users WHERE id = $1', [sub.customer_id]);
    await notifyRejected(sub, custQ.rows[0], reason);

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/submissions/:id
router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    await query('DELETE FROM submissions WHERE id = $1', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/submissions/export/csv
router.get('/export/csv', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT s.id, s.customer_name, s.country, s.month, s.distributor_name, s.status,
             s.boxes_displayed, s.reams_purchased, s.posm_displayed, s.eligible_incentive,
             s.incentive_amount, s.currency, s.distributor_helped, s.reviewer_note, s.submitted_at,
             u.email AS customer_email
      FROM submissions s LEFT JOIN users u ON s.customer_id = u.id
      ORDER BY s.submitted_at DESC
    `);

    const cols = ['ID','Customer','Email','Country','Month','Distributor','Helped','Status',
      'Boxes Displayed','Reams Purchased','POSM Displayed','Eligible','Incentive Amount','Currency','Reviewer Note','Submitted'];
    const header = cols.map(c => `"${c}"`).join(',') + '\n';
    const csv = rows.map(r =>
      [r.id, r.customer_name, r.customer_email, r.country, r.month, r.distributor_name,
       r.distributor_helped, r.status, r.boxes_displayed, r.reams_purchased, r.posm_displayed,
       r.eligible_incentive, r.incentive_amount, r.currency, r.reviewer_note, r.submitted_at]
        .map(v => `"${(v || '').toString().replace(/"/g, '""')}"`)
        .join(',')
    ).join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=submissions-${Date.now()}.csv`);
    res.send(header + csv);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
