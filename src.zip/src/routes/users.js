// src/routes/users.js
const router = require('express').Router();
const { query } = require('../utils/db');
const { verifyToken, requireAdmin } = require('../middleware/auth');
const { notifyRegistrationApproved } = require('../utils/email');

// GET /api/users — all channel users (admin only)
router.get('/', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT id, role, name, business, email, approved, country, pincode, address, mobile, shop_photo_url, created_at
      FROM users WHERE role = 'channel'
      ORDER BY created_at DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/users/pending — pending approvals
router.get('/pending', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT id, name, business, email, country, pincode, address, mobile, shop_photo_url, created_at
      FROM users WHERE role = 'channel' AND approved = FALSE
      ORDER BY created_at DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PATCH /api/users/:id/approve
router.patch('/:id/approve', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { rows } = await query(
      'UPDATE users SET approved = TRUE, updated_at = NOW() WHERE id = $1 AND role = \'channel\' RETURNING *',
      [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'User not found' });

    await query('INSERT INTO audit_log (action, actor, target, detail) VALUES ($1,$2,$3,$4)',
      ['Customer Approved', req.user.email, req.params.id, `${rows[0].business} approved`]);

    // Send approval email to customer
    await notifyRegistrationApproved(rows[0]);

    res.json({ success: true, user: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/users/:id
router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { rows } = await query('SELECT business, email FROM users WHERE id = $1', [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: 'User not found' });

    await query('DELETE FROM users WHERE id = $1 AND role = \'channel\'', [req.params.id]);
    await query('INSERT INTO audit_log (action, actor, target, detail) VALUES ($1,$2,$3,$4)',
      ['Customer Removed', req.user.email, req.params.id, `${rows[0].business} removed`]);

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/users/export — CSV export
router.get('/export', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT id, name, business, email, country, pincode, address, mobile,
             CASE WHEN approved THEN 'Active' ELSE 'Pending' END as status, created_at
      FROM users WHERE role = 'channel' ORDER BY created_at DESC
    `);

    const header = 'Customer ID,Name,Business,Email,Country,Pincode,Address,Mobile,Status,Registered\n';
    const csv = rows.map(r =>
      [r.id, r.name, r.business, r.email, r.country, r.pincode, r.address, r.mobile, r.status, r.created_at]
        .map(v => `"${(v || '').toString().replace(/"/g, '""')}"`)
        .join(',')
    ).join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=customers-${Date.now()}.csv`);
    res.send(header + csv);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
