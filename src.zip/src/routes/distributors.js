// src/routes/distributors.js
const router = require('express').Router();
const { query } = require('../utils/db');
const { verifyToken, requireAdmin } = require('../middleware/auth');

function uid() { return Math.random().toString(36).slice(2, 8).toUpperCase(); }

router.get('/', verifyToken, async (req, res) => {
  const { rows } = await query('SELECT * FROM distributors ORDER BY name ASC');
  res.json(rows);
});

router.post('/', verifyToken, requireAdmin, async (req, res) => {
  const { name, country } = req.body;
  if (!name) return res.status(400).json({ error: 'Name required' });
  const id = 'DIST-' + uid();
  const { rows } = await query(
    'INSERT INTO distributors (id, name, country) VALUES ($1,$2,$3) RETURNING *',
    [id, name, country || '']
  );
  await query('INSERT INTO audit_log (action, actor, target, detail) VALUES ($1,$2,$3,$4)',
    ['Distributor Added', req.user.email, id, name + ' added']);
  res.status(201).json(rows[0]);
});

router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  await query('DELETE FROM distributors WHERE id = $1', [req.params.id]);
  res.json({ success: true });
});

module.exports = router;
