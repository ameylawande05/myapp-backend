// src/routes/reports.js
const router = require('express').Router();
const { query } = require('../utils/db');
const { verifyToken, requireAdmin } = require('../middleware/auth');

router.get('/summary', verifyToken, requireAdmin, async (req, res) => {
  const [total, approved, pending, rejected, customers, pendingApproval] = await Promise.all([
    query("SELECT COUNT(*) FROM submissions"),
    query("SELECT COUNT(*) FROM submissions WHERE status='Approved'"),
    query("SELECT COUNT(*) FROM submissions WHERE status='Pending Review'"),
    query("SELECT COUNT(*) FROM submissions WHERE status='Rejected'"),
    query("SELECT COUNT(*) FROM users WHERE role='channel' AND approved=TRUE"),
    query("SELECT COUNT(*) FROM users WHERE role='channel' AND approved=FALSE"),
  ]);
  res.json({
    total:          parseInt(total.rows[0].count),
    approved:       parseInt(approved.rows[0].count),
    pending:        parseInt(pending.rows[0].count),
    rejected:       parseInt(rejected.rows[0].count),
    customers:      parseInt(customers.rows[0].count),
    pendingApproval:parseInt(pendingApproval.rows[0].count),
  });
});

router.get('/by-country', verifyToken, requireAdmin, async (req, res) => {
  const { rows } = await query(`
    SELECT country,
      COUNT(*) AS total,
      SUM(CASE WHEN status='Approved'       THEN 1 ELSE 0 END) AS approved,
      SUM(CASE WHEN status='Pending Review' THEN 1 ELSE 0 END) AS pending,
      SUM(CASE WHEN status='Rejected'       THEN 1 ELSE 0 END) AS rejected
    FROM submissions GROUP BY country ORDER BY total DESC
  `);
  res.json(rows);
});

router.get('/audit', verifyToken, requireAdmin, async (req, res) => {
  const { rows } = await query('SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 500');
  res.json(rows);
});

router.get('/audit/export', verifyToken, requireAdmin, async (req, res) => {
  const { rows } = await query('SELECT * FROM audit_log ORDER BY created_at DESC');
  const header = '"Timestamp","Action","Actor","Target","Detail"\n';
  const csv = rows.map(r =>
    [r.created_at, r.action, r.actor, r.target, r.detail]
      .map(v => `"${(v || '').toString().replace(/"/g, '""')}"`)
      .join(',')
  ).join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename=audit-log-${Date.now()}.csv`);
  res.send(header + csv);
});

module.exports = router;
