// src/routes/notifications.js
const router = require('express').Router();
const { query } = require('../utils/db');
const { verifyToken, requireAdmin } = require('../middleware/auth');

router.get('/', verifyToken, requireAdmin, async (req, res) => {
  const { rows } = await query('SELECT * FROM notification_emails ORDER BY created_at DESC');
  res.json(rows);
});

router.post('/', verifyToken, requireAdmin, async (req, res) => {
  const { email, label } = req.body;
  if (!email) return res.status(400).json({ error: 'Email required' });
  const { rows } = await query(`
    INSERT INTO notification_emails (email, label, added_by)
    VALUES ($1, $2, $3)
    ON CONFLICT (email) DO UPDATE SET active = TRUE, label = $2
    RETURNING *
  `, [email.toLowerCase().trim(), label || '', req.user.id]);
  res.status(201).json(rows[0]);
});

router.patch('/:id', verifyToken, requireAdmin, async (req, res) => {
  const { active } = req.body;
  await query('UPDATE notification_emails SET active = $1 WHERE id = $2', [active, req.params.id]);
  res.json({ success: true });
});

router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  await query('DELETE FROM notification_emails WHERE id = $1', [req.params.id]);
  res.json({ success: true });
});

module.exports = router;
