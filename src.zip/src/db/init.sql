-- ════════════════════════════════════════════════════════════════
--  DOUBLE A CME-BME CLAIMS — Database Schema
--  Run: psql $DATABASE_URL -f src/db/init.sql
-- ════════════════════════════════════════════════════════════════

-- Users table (admin + channel customers)
CREATE TABLE IF NOT EXISTS users (
  id              VARCHAR(30)  PRIMARY KEY,
  role            VARCHAR(20)  NOT NULL DEFAULT 'channel',
  name            VARCHAR(200) NOT NULL,
  business        VARCHAR(200),
  email           VARCHAR(200) UNIQUE NOT NULL,
  password_hash   VARCHAR(200) NOT NULL,
  approved        BOOLEAN      NOT NULL DEFAULT FALSE,
  country         VARCHAR(100),
  pincode         VARCHAR(20),
  address         TEXT,
  mobile          VARCHAR(30),
  shop_photo_url  TEXT,
  created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Distributors (admin manages, customers pick from dropdown)
CREATE TABLE IF NOT EXISTS distributors (
  id          VARCHAR(30)  PRIMARY KEY,
  name        VARCHAR(300) NOT NULL,
  country     VARCHAR(100),
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Submissions (core claim records)
CREATE TABLE IF NOT EXISTS submissions (
  id                   VARCHAR(30)  PRIMARY KEY,
  customer_id          VARCHAR(30)  NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  customer_name        VARCHAR(300),
  country              VARCHAR(100),
  month                VARCHAR(30),
  distributor_id       VARCHAR(30)  REFERENCES distributors(id),
  distributor_name     VARCHAR(300),
  display_video_url    TEXT,
  display_video_name   VARCHAR(300),
  photo1_url           TEXT,
  photo1_name          VARCHAR(300),
  business_card_url    TEXT,
  business_card_name   VARCHAR(300),
  distributor_helped   VARCHAR(5)   DEFAULT 'Yes',
  status               VARCHAR(30)  NOT NULL DEFAULT 'Pending Review',
  reviewer_note        TEXT,
  reviewed_by          VARCHAR(30)  REFERENCES users(id),
  reviewed_at          TIMESTAMPTZ,
  boxes_displayed      VARCHAR(100),
  reams_purchased      VARCHAR(100),
  posm_displayed       VARCHAR(100),
  eligible_incentive   VARCHAR(10),
  incentive_amount     VARCHAR(100),
  currency             VARCHAR(10),
  version              INTEGER      NOT NULL DEFAULT 1,
  submitted_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Invoices (up to 5 per submission)
CREATE TABLE IF NOT EXISTS submission_invoices (
  id            SERIAL       PRIMARY KEY,
  submission_id VARCHAR(30)  NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
  file_url      TEXT         NOT NULL,
  file_name     VARCHAR(300),
  file_size     BIGINT,
  uploaded_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Notification email list (admin manages who gets alerts)
CREATE TABLE IF NOT EXISTS notification_emails (
  id          SERIAL       PRIMARY KEY,
  email       VARCHAR(200) UNIQUE NOT NULL,
  label       VARCHAR(200),
  active      BOOLEAN      NOT NULL DEFAULT TRUE,
  added_by    VARCHAR(30)  REFERENCES users(id),
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Audit log
CREATE TABLE IF NOT EXISTS audit_log (
  id          SERIAL       PRIMARY KEY,
  action      VARCHAR(100),
  actor       VARCHAR(200),
  target      VARCHAR(100),
  detail      TEXT,
  ip_address  VARCHAR(50),
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_submissions_customer  ON submissions(customer_id);
CREATE INDEX IF NOT EXISTS idx_submissions_status    ON submissions(status);
CREATE INDEX IF NOT EXISTS idx_submissions_country   ON submissions(country);
CREATE INDEX IF NOT EXISTS idx_submissions_submitted ON submissions(submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_created         ON audit_log(created_at DESC);

-- Default notification email
INSERT INTO notification_emails (email, label)
VALUES ('lawande_a@doublea1991.com', 'Head Office – Bangkok')
ON CONFLICT (email) DO NOTHING;

-- Default distributors
INSERT INTO distributors (id, name, country) VALUES
  ('DIST-001', 'Alpha Distributors Pvt Ltd',  'India'),
  ('DIST-002', 'Santos Trading Corporation',   'Philippines'),
  ('DIST-003', 'Bangkok Office Supplies Co.',  'Thailand'),
  ('DIST-004', 'Himalayan Paper Traders',       'Nepal'),
  ('DIST-005', 'Kuala Lumpur Stationery Hub',  'Malaysia')
ON CONFLICT DO NOTHING;
