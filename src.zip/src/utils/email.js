// src/utils/email.js
const nodemailer = require('nodemailer');
const { query }  = require('./db');

const FROM_NAME  = process.env.EMAIL_FROM_NAME || 'Double A Claims';
const FROM_EMAIL = process.env.EMAIL_FROM      || 'noreply@doublea-claims.com';
const FE_URL     = process.env.FRONTEND_URL    || 'https://doublea-claims.com';

// SendGrid SMTP transport
const transporter = nodemailer.createTransport({
  host: 'smtp.sendgrid.net',
  port: 587,
  secure: false,
  auth: {
    user: 'apikey',
    pass: process.env.SENDGRID_API_KEY,
  },
});

// ─── Email Base Template ───────────────────────────────────────
function baseHtml(bodyHtml) {
  return `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<style>
  body{margin:0;padding:0;background:#F0F4F8;font-family:'Segoe UI',Arial,sans-serif}
  .wrap{max-width:600px;margin:32px auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #E2E8F0;box-shadow:0 4px 24px rgba(0,0,0,0.07)}
  .header{background:linear-gradient(135deg,#0F172A 0%,#1E3A5F 100%);padding:28px 36px;text-align:center}
  .header-title{font-size:26px;font-weight:900;color:#fff;letter-spacing:1px;margin:0}
  .header-sub{font-size:12px;color:#60A5FA;margin-top:5px;letter-spacing:2px;text-transform:uppercase}
  .body{padding:32px 36px}
  .footer{background:#F8FAFC;padding:18px 36px;text-align:center;border-top:1px solid #E2E8F0}
  .footer p{font-size:12px;color:#94A3B8;margin:3px 0}
  table.info{width:100%;border-collapse:collapse;margin:16px 0}
  table.info td{padding:10px 0;border-bottom:1px solid #F1F5F9;font-size:13px}
  table.info td:first-child{color:#64748B;width:42%}
  table.info td:last-child{font-weight:600;color:#0F172A}
  .btn{display:inline-block;padding:12px 28px;border-radius:9px;font-weight:700;font-size:14px;text-decoration:none;margin-top:20px}
  .btn-primary{background:linear-gradient(135deg,#0F172A,#1E3A5F);color:#fff}
  .btn-green{background:linear-gradient(135deg,#16A34A,#0D9488);color:#fff}
  .btn-blue{background:linear-gradient(135deg,#2563EB,#0D9488);color:#fff}
  .alert{border-radius:10px;padding:18px 20px;margin:16px 0;text-align:center}
  .alert-green{background:#F0FDF4;border:1.5px solid #86EFAC}
  .alert-red{background:#FEF2F2;border:1.5px solid #FCA5A5}
  .alert-yellow{background:#FFF7ED;border-left:4px solid #F59E0B;border-radius:4px;text-align:left}
  h2{color:#0F172A;margin:0 0 8px;font-size:20px}
  p{color:#374151;font-size:14px;line-height:1.8;margin:10px 0}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <div class="header-title">Double A®</div>
    <div class="header-sub">CME-BME Claims Submissions Platform</div>
  </div>
  <div class="body">${bodyHtml}</div>
  <div class="footer">
    <p><strong>doublea-claims.com</strong> · Bangkok, Thailand</p>
    <p>© 2026 Double A (1991) Public Company Limited. All rights reserved.</p>
    <p>This is an automated message. Do not reply to this email.</p>
  </div>
</div>
</body>
</html>`;
}

// ─── Template: New submission → Head office ────────────────────
function tplNewSubmission(sub) {
  return baseHtml(`
    <h2>📤 New Claim Submission Received</h2>
    <p>A new CME-BME claim has been submitted and requires your review.</p>
    <table class="info">
      <tr><td>Customer</td><td>${sub.customer_name}</td></tr>
      <tr><td>Customer ID</td><td style="color:#0D9488;font-family:monospace">${sub.customer_id}</td></tr>
      <tr><td>Country</td><td>${sub.country}</td></tr>
      <tr><td>Claim Month</td><td>${sub.month}</td></tr>
      <tr><td>Distributor</td><td>${sub.distributor_name}</td></tr>
      <tr><td>Submission ID</td><td style="color:#7C3AED;font-family:monospace">${sub.id}</td></tr>
      <tr><td>Submitted At</td><td>${new Date(sub.submitted_at).toLocaleString('en-GB')}</td></tr>
    </table>
    <a href="${FE_URL}" class="btn btn-primary">Review Submission →</a>
  `);
}

// ─── Template: Claim approved → Customer ──────────────────────
function tplApproved(sub, customer) {
  return baseHtml(`
    <div class="alert alert-green">
      <div style="font-size:44px;margin-bottom:8px">✅</div>
      <h2 style="color:#16A34A;margin:0">Your Claim is Approved!</h2>
      <p style="color:#4ADE80;margin:4px 0 0;font-size:13px">Your CME-BME incentive claim has been verified and approved.</p>
    </div>
    <p>Dear <strong>${customer.name || customer.business}</strong>,</p>
    <p>We are pleased to confirm that your claim submission for <strong>${sub.month}</strong> has been <strong style="color:#16A34A">approved</strong> by our team.</p>
    <table class="info">
      <tr><td>Submission ID</td><td style="color:#7C3AED;font-family:monospace">${sub.id}</td></tr>
      <tr><td>Claim Month</td><td>${sub.month}</td></tr>
      <tr><td>Incentive Amount</td><td style="color:#16A34A;font-size:16px;font-weight:700">${sub.incentive_amount} ${sub.currency}</td></tr>
      <tr><td>Approved On</td><td>${new Date(sub.reviewed_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}</td></tr>
    </table>
    <p>Our distributor team will coordinate the incentive disbursement with you shortly.</p>
    <p>For questions, contact us at <a href="mailto:lawande_a@doublea1991.com" style="color:#0D9488">lawande_a@doublea1991.com</a> or WhatsApp <a href="https://wa.me/66858353979" style="color:#0D9488">+66 85 835 3979</a>.</p>
    <a href="${FE_URL}" class="btn btn-green">View My Dashboard →</a>
  `);
}

// ─── Template: Claim rejected → Customer ──────────────────────
function tplRejected(sub, customer, reason) {
  return baseHtml(`
    <div class="alert alert-red">
      <div style="font-size:44px;margin-bottom:8px">❌</div>
      <h2 style="color:#DC2626;margin:0">Claim Requires Correction</h2>
    </div>
    <p>Dear <strong>${customer.name || customer.business}</strong>,</p>
    <p>Your claim submission for <strong>${sub.month}</strong> has been reviewed and requires correction before it can be approved.</p>
    <div class="alert alert-yellow">
      <div style="font-size:11px;font-weight:700;color:#92400E;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px">Reason for Rejection</div>
      <div style="font-size:14px;color:#78350F;font-weight:600">${reason}</div>
    </div>
    <table class="info">
      <tr><td>Submission ID</td><td style="font-family:monospace;color:#7C3AED">${sub.id}</td></tr>
      <tr><td>Claim Month</td><td>${sub.month}</td></tr>
    </table>
    <p>Please correct the issues mentioned above and resubmit your claim through the portal.</p>
    <p>Need help? Contact us at <a href="mailto:lawande_a@doublea1991.com" style="color:#0D9488">lawande_a@doublea1991.com</a></p>
    <a href="${FE_URL}" class="btn btn-blue">Resubmit Claim →</a>
  `);
}

// ─── Template: Registration approved → Customer ───────────────
function tplRegistrationApproved(customer) {
  return baseHtml(`
    <div class="alert alert-green">
      <div style="font-size:44px;margin-bottom:8px">🎉</div>
      <h2 style="color:#16A34A;margin:0">Account Approved!</h2>
      <p style="color:#4ADE80;margin:4px 0 0;font-size:13px">You can now submit CME-BME claims.</p>
    </div>
    <p>Dear <strong>${customer.name || customer.business}</strong>,</p>
    <p>Your registration on the Double A CME-BME Claims platform has been <strong style="color:#16A34A">approved</strong>!</p>
    <table class="info">
      <tr><td>Customer ID</td><td style="color:#0D9488;font-family:monospace;font-size:18px;font-weight:700">${customer.id}</td></tr>
      <tr><td>Business</td><td>${customer.business}</td></tr>
      <tr><td>Country</td><td>${customer.country}</td></tr>
      <tr><td>Platform URL</td><td><a href="${FE_URL}" style="color:#2563EB">${FE_URL}</a></td></tr>
    </table>
    <p>You can now log in and start submitting your monthly CME-BME claims. Keep your Customer ID safe — you'll need it for all communications.</p>
    <a href="${FE_URL}" class="btn btn-primary">Login & Submit Claims →</a>
  `);
}

// ─── Send helpers ──────────────────────────────────────────────
async function send(to, subject, html) {
  if (!process.env.SENDGRID_API_KEY || process.env.SENDGRID_API_KEY === 'SG.your_sendgrid_api_key_here') {
    console.log(`[EMAIL SKIPPED - no API key] To: ${to} | Subject: ${subject}`);
    return;
  }
  try {
    await transporter.sendMail({ from: `"${FROM_NAME}" <${FROM_EMAIL}>`, to, subject, html });
    console.log(`✅ Email sent to ${to}`);
  } catch (err) {
    console.error(`❌ Email failed to ${to}:`, err.message);
  }
}

async function notifyNewSubmission(sub) {
  try {
    const { rows } = await query('SELECT email FROM notification_emails WHERE active = TRUE');
    if (!rows.length) return console.log('No notification emails configured');
    const to = rows.map(r => r.email).join(',');
    await send(to, `📤 New Claim: ${sub.customer_name} – ${sub.month} [${sub.id}]`, tplNewSubmission(sub));
  } catch (e) { console.error('notifyNewSubmission:', e.message); }
}

async function notifyApproved(sub, customer) {
  await send(customer.email, `✅ Your Double A Claim is Approved – ${sub.month}`, tplApproved(sub, customer));
}

async function notifyRejected(sub, customer, reason) {
  await send(customer.email, `⚠️ Action Required – Double A Claim ${sub.month}`, tplRejected(sub, customer, reason));
}

async function notifyRegistrationApproved(customer) {
  await send(customer.email, `🎉 Your Double A Claims Account is Approved – ID: ${customer.id}`, tplRegistrationApproved(customer));
}

module.exports = { notifyNewSubmission, notifyApproved, notifyRejected, notifyRegistrationApproved };
