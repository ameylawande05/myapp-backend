// src/utils/db.js
const { Pool } = require('pg');
const bcrypt   = require('bcryptjs');
const fs       = require('fs');
const path     = require('path');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('error', (err) => {
  console.error('Unexpected DB error:', err);
});

async function query(sql, params = []) {
  const client = await pool.connect();
  try {
    return await client.query(sql, params);
  } finally {
    client.release();
  }
}

async function initDb() {
  const sqlFile = path.join(__dirname, '../db/init.sql');
  if (fs.existsSync(sqlFile)) {
    const sql = fs.readFileSync(sqlFile, 'utf8');
    await query(sql);
    console.log('✅ Database schema initialized');
  }
}

async function seedAdmin() {
  const email    = process.env.SUPER_ADMIN_EMAIL    || 'ameylawande05@gmail.com';
  const password = process.env.SUPER_ADMIN_PASSWORD || 'Doublea0511';
  const name     = process.env.SUPER_ADMIN_NAME     || 'Amey Lawande';
  const hash     = await bcrypt.hash(password, 12);

  await query(`
    INSERT INTO users (id, role, name, email, password_hash, approved, country)
    VALUES ('ADM001', 'admin', $1, $2, $3, TRUE, 'Thailand')
    ON CONFLICT (email) DO UPDATE
      SET password_hash = $3, name = $1, updated_at = NOW()
  `, [name, email, hash]);

  console.log('✅ Super admin seeded:', email);
}

module.exports = { query, pool, initDb, seedAdmin };
