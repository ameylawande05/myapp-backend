// src/middleware/upload.js
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { S3Client } = require('@aws-sdk/client-s3');
const multerS3 = require('multer-s3');

const USE_S3    = process.env.STORAGE_TYPE === 's3';
const UPLOAD_DIR = process.env.UPLOAD_DIR   || './uploads';

// Ensure local upload directory exists
if (!USE_S3) {
  ['videos', 'photos', 'invoices', 'shopfront'].forEach(dir => {
    const p = path.join(UPLOAD_DIR, dir);
    if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
  });
}

// S3 client
const s3 = USE_S3 ? new S3Client({
  region: process.env.AWS_REGION || 'ap-southeast-1',
  credentials: {
    accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
}) : null;

function makeStorage(folder) {
  if (USE_S3) {
    return multerS3({
      s3,
      bucket: process.env.S3_BUCKET_NAME || 'doublea-claims-files',
      contentType: multerS3.AUTO_CONTENT_TYPE,
      key: (req, file, cb) => {
        const ext  = path.extname(file.originalname).toLowerCase();
        const name = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`;
        cb(null, name);
      },
    });
  }
  return multer.diskStorage({
    destination: (req, file, cb) => cb(null, path.join(UPLOAD_DIR, folder)),
    filename:    (req, file, cb) => {
      const ext  = path.extname(file.originalname).toLowerCase();
      cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
    },
  });
}

function getFileUrl(req, file) {
  if (USE_S3) return file.location;
  const relativePath = file.path.replace(UPLOAD_DIR, '').replace(/\\/g, '/');
  const base = process.env.BACKEND_URL || `http://localhost:${process.env.PORT || 5000}`;
  return `${base}/uploads${relativePath}`;
}

// Multer filter factories
const videoFilter = (req, file, cb) => {
  const allowed = ['.mp4', '.mov', '.avi', '.webm', '.mkv'];
  const ext = path.extname(file.originalname).toLowerCase();
  allowed.includes(ext) ? cb(null, true) : cb(new Error('Only video files allowed (mp4, mov, avi, webm)'));
};
const imageFilter = (req, file, cb) => {
  const allowed = ['.jpg', '.jpeg', '.png', '.webp'];
  const ext = path.extname(file.originalname).toLowerCase();
  allowed.includes(ext) ? cb(null, true) : cb(new Error('Only image files allowed (jpg, png, webp)'));
};
const docFilter = (req, file, cb) => {
  const allowed = ['.pdf', '.jpg', '.jpeg', '.png', '.xlsx', '.xls'];
  const ext = path.extname(file.originalname).toLowerCase();
  allowed.includes(ext) ? cb(null, true) : cb(new Error('Only PDF, image, or Excel files allowed'));
};
const anyImageFilter = (req, file, cb) => {
  const allowed = ['.jpg', '.jpeg', '.png', '.webp', '.pdf'];
  const ext = path.extname(file.originalname).toLowerCase();
  allowed.includes(ext) ? cb(null, true) : cb(new Error('Only image/PDF files allowed'));
};

// Submission upload — handles all fields at once
const submissionUpload = multer({
  storage: makeStorage('submissions'),
  limits: { fileSize: 100 * 1024 * 1024 }, // 100 MB global limit
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const videoExts  = ['.mp4', '.mov', '.avi', '.webm', '.mkv'];
    const imageExts  = ['.jpg', '.jpeg', '.png', '.webp'];
    const docExts    = ['.pdf', '.xlsx', '.xls'];
    const allAllowed = [...videoExts, ...imageExts, ...docExts];
    allAllowed.includes(ext) ? cb(null, true) : cb(new Error(`File type ${ext} not allowed`));
  },
}).fields([
  { name: 'displayVideo', maxCount: 1 },
  { name: 'photo1',       maxCount: 1 },
  { name: 'businessCard', maxCount: 1 },
  { name: 'invoices',     maxCount: 5 },
]);

// Shop photo upload for registration
const shopPhotoUpload = multer({
  storage: makeStorage('shopfront'),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: anyImageFilter,
}).single('shopPhoto');

module.exports = { submissionUpload, shopPhotoUpload, getFileUrl };
